/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

/**
 *
 * @author JOHAN
 */
public class Computador extends Electronico {

    public enum SistemaOperativo{
       WINDOWS,LINUX,MACOS;   
    }
           
private SistemaOperativo sistemaOperativo;
        
   public Computador(Gama pGama, double pPrecio,SistemaOperativo psistemaOperativo) {
        super(pGama, pPrecio);
    sistemaOperativo= psistemaOperativo;
    }

    @Override
    public String toString() {
        return "Computador{" + "sistemaOperativo=" + sistemaOperativo + '}';
    }
   
}


        

